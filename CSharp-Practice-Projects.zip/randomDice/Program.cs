﻿Random Dice = new Random(); 
//建立一個亂數產生器叫Dice。//
int roll = Dice.Next(1,7); 
//呼叫dice.Next(1,7) 產生一個1到6之間的整數(不包含7),並把這個數字存在 roll這個變數理。這行就是「擲骰子」的動作。//
Console.WriteLine(roll);
//印出「擲骰子」的結果。//


/* 
Python 寫法
import random
roll = random.randint(1,7)
print(roll)
*/