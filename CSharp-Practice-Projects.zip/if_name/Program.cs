﻿string[] name = { "Van", "Makudo", "Curly", "Angeline", "Moon", "Joy" };
for (int i = 0; i < name.Length; i++)
{
    if (name[i] == "Moon")
    {
        name[i] = "Lily";
    }
}
foreach (var item in name)
{
    Console.WriteLine(item);
}