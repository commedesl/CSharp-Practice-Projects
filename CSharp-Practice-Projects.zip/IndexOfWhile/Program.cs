﻿string[] myStrings = new string[2] { "I like pizza. I like roast chicken. I like salad", "I like all three of the menu choices" };
//宣告一個字串陣列 myStrings，裡面有兩個字串。
//第一個字串包含三個句子，每句以句號結尾。第二個字串只有一個句子，沒有句號。
int stringsCount = myStrings.Length; //取得陣列中元素的數量，這裡是 2。

string myString = ""; //宣告一個空字串 myString 用來暫存目前處理的字串。
int periodLocation = 0;  //宣告整數 periodLocation 用來記錄句號在字串中的位置。

for (int i = 0; i < stringsCount; i++)//使用 for 迴圈遍歷陣列中的每個字串。
{
    myString = myStrings[i];//將目前字串指定給 myString。
    periodLocation = myString.IndexOf("."); //使用 IndexOf(".") 找出第一個句號的位置，如果找不到句號會回傳 -1。

    string mySentence;//宣告一個字串變數 mySentence，用來存放擷取出來的句子。

    //進入 while 迴圈，當字串中還有句號時持續執行。
    while (periodLocation != -1)
    {
        // 使用 Remove(periodLocation) 將字串從句號位置開始移除，留下句號前的文字，這就是一個完整的句子。
        mySentence = myString.Remove(periodLocation);

        // 將 myString 更新為句號之後的字串（不包含句號本身），準備處理下一個句子。
        myString = myString.Substring(periodLocation + 1);

        // 移除字串開頭的空白字元，避免下一個句子前有多餘空格。
        myString = myString.TrimStart();

        // 再次尋找下一個句號位置
        periodLocation = myString.IndexOf(".");

        //印出剛剛擷取的句子。
        Console.WriteLine(mySentence);
    }
    //當 while 迴圈結束（表示字串中已無句號），將剩餘字串（最後一個句子或整個字串，如果沒有句號）去除頭尾空白後印出。
    mySentence = myString.Trim();
    Console.WriteLine(mySentence);
}
