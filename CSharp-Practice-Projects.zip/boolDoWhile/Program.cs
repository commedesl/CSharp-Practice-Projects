﻿string? readresult;
bool validEntry = false;
Console.WriteLine("Enter a string containing at least 3 chars.");
do
{
    readresult = Console.ReadLine();
    if (readresult != null)
    {
        if (readresult.Length >= 3)
            validEntry = true;
        else
            Console.WriteLine("Your enter is invalid. Enter at least 3 chars.");
    }
} while (validEntry == false);
