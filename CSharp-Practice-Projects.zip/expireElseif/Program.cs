﻿Random random = new Random();
int expiredays=random.Next(13);
int discount = 0;

if (expiredays == 0) 
{
    Console.WriteLine("Your subscription has expired.");
}
else if (expiredays == 1)
{
    Console.WriteLine("Your subscription expires within a day!");
    discount = 20;
}
else if (expiredays <= 12)
{
    Console.WriteLine($"Your subscription expires in {expiredays} days.");
    discount = 10;
}

if (discount > 0)
{
    Console.WriteLine($"subscribe now and save {discount} %.");
}