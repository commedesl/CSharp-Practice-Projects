﻿int hero = 10;
int monster = 10;
Random dice = new Random();
do
{
    int roll = dice.Next(1, 11);
    monster -= roll;
    Console.WriteLine($"Moster was lost {roll} point and now has {monster} point.");

    if (monster <= 0) continue;//非常小心使用 continue，因為它會跳過當次迴圈後面所有的程式碼，直接進入下一輪。

    roll = dice.Next(1, 11);
    hero -= roll;
    Console.WriteLine($"Hero was lost {roll} point and now has {hero} point.");
} while (hero > 0 && monster > 0);
Console.WriteLine(hero> monster? "Hero wins!":"monster wins!");