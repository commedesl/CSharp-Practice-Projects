﻿string? readresult;
string rollName = "";
bool entry = false;
do
{
    Console.WriteLine("Enter your roll name (Rich, Lily, or Momo)");
    readresult = Console.ReadLine();
    if (readresult != null)
        rollName = readresult.Trim();
    else
        rollName = "";

    string rollNameLower = rollName.ToLower();

    if (rollNameLower == "rich" || rollNameLower == "lily" || rollNameLower == "momo")
        entry = true;
    else
        Console.WriteLine($"sorry, you enter invalid Name {rollName}.");
} while (entry == false);
Console.WriteLine($"Your input {rollName} has been accepted.");


    
