﻿// SKU = Stock Keeping Unit. 
// SKU value format: <product #>-<2-letter color code>-<size code>
string sku = "01-MN-L";
string[] product = sku.Split('-');

string type = "";
string color = "";
string size = "";

switch (product[0])
{
    case "01":
        type = "Sweat shirt";
        break;
    case "02":
        type = "T-Shirt";
        break;
    case "03":
        type = "Sweat pants";
        break;
    default:
        type = "other";
        break;
}
switch (product[1])
{
    case "BL":
        color = "Black";
        break;
    case "MN":
        color = "Maroon";
        break;
    default:
        color = "White";
        break;
}

switch (product[2])
{
    case "s":
        size = "Small";
        break;
    case "M":
        size = "Medium";
        break;
    case "L":
        size = "Large";
        break;
    default:
        size = "One Size Fits All";
        break;
}
Console.WriteLine($"Product: {size} {color} {type}");

/* 5/20的練習
string sku = "01-RC-L";
string[] product = sku.Split('-');
string type = "";
string color = "";
string size = "";

switch (product[0])
{
    case "01":
        type = "sweater";
        break;
    case "02":
        type = "T-shirt";
        break;
}
switch (product[1])
{
    case "RC":
        color = "Rich";
        break;
    case "WH":
        color = "White";
        break;
}
switch (product[2])
{
    case "M":
        size = "medium";
        break;
    case "L":
        size = "Large";
        break;
}
Console.WriteLine($"Product :{type} {color} {size}");*/