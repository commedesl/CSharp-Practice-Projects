﻿string readresult = "123";
int value;  // 沒有初始值
bool validnumber = int.TryParse(readresult, out value);
if (validnumber)
{
    Console.WriteLine($"transfer OK! Value is {value}.");
}
else
{
    Console.WriteLine("Sorry, transfer failed.");
    // 這裡 numericValue 會是 0（因為轉換失敗）
}