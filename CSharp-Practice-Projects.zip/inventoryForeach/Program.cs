﻿int[] inventory = [200, 350, 400, 150, 600];
int sum = 0;
int bin = 0;
foreach (int item in inventory)
{
    sum += item;
    bin++;
    Console.WriteLine($"Bin {bin} = {item} items (Running total: {sum})");
}
Console.WriteLine($"We have total {sum} inventory.\n ");

