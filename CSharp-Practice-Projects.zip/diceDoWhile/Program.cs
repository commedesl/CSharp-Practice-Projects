﻿Random Dice = new Random();// 建立一個 Random 物件，用來產生隨機數字
int current = Dice.Next(1,11);//呼叫 Next(1, 11) 會產生 1～10 之間的整數（不含 11）。
                                //第一次丟骰子，產生一個隨機值放進 current。
do
{
    current = Dice.Next(1,11);  // 再次產生 1~10 的亂數
    if (current >= 8) continue; // 如果數字是 8、9、10，就跳過本次迴圈，不執行
    Console.WriteLine(current); // 印出 current（但只有在 < 8 時才會印）
} while (current != 7);         // 當 current 不是 7，就繼續迴圈


//持續擲骰子（隨機產生數字），只要數字大於等於 3，就印出來，直到骰出小於 3 的數字為止，然後印出最後那個數字。
/*while (current >= 3)             //只要 current ≥ 3 就一直重複
{
    Console.WriteLine(current);    //顯示目前值
    current = Dice.Next(1, 8);     //再擲一次骰子 → 使用 Dice.Next(1, 8) → 得到 1～7 之間的整數
}                                  //當 current 小於 3（也就是 1 或 2）時，跳出 while 迴圈。

Console.WriteLine($"Last no.:{current}");  */
//印出最後那個結束的數字（也就是 <3 的數字），這個數字不會在上面的 while 裡被印出來，所以特別印在最後。